# @wrelik/email

## 0.1.3

### Patch Changes

- Updated dependencies [2b9cbf7]
  - @wrelik/errors@0.2.1

## 0.1.2

### Patch Changes

- a38ebcb: Add React Native / Expo support and enforce server-only boundaries.
- Updated dependencies [a38ebcb]
  - @wrelik/errors@0.2.0

## 0.1.1

### Patch Changes

- Update publishConfig to access:public for all packages.
- Updated dependencies
  - @wrelik/errors@0.1.1

## 0.1.0

### Minor Changes

- ad849e3: Initial release of all wrelik-kit packages.

### Patch Changes

- Updated dependencies [ad849e3]
  - @wrelik/errors@0.1.0
